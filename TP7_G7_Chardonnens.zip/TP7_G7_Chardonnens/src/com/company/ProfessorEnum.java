package com.company;

public class ProfessorEnum {

    public enum ProfessorName{
        SORBIER, SEKO, CHEN
    }
}
